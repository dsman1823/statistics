/*
 *  /MathJax/fonts/HTML-CSS/TeX/png/Main/Italic/LetterlikeSymbols.js
 *  
 *  Copyright (c) 2010-2013 The MathJax Consortium
 *
 *  Part of the MathJax library.
 *  See http://www.mathjax.org for details.
 * 
 *  Licensed under the Apache License, Version 2.0;
 *  you may not use this file except in compliance with the License.
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 */

MathJax.OutputJax["HTML-CSS"].defineImageData({"MathJax_Main-italic":{8463:[[4,6,1],[5,7,1],[6,7,0],[7,10,1],[8,11,1],[10,13,1],[11,15,1],[13,18,1],[16,21,1],[19,24,1],[22,29,1],[27,34,1],[32,40,1],[37,47,1]]}});MathJax.Ajax.loadComplete(MathJax.OutputJax["HTML-CSS"].imgDir+"/Main/Italic"+MathJax.OutputJax["HTML-CSS"].imgPacked+"/LetterlikeSymbols.js");

